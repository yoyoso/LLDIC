/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Comedi major version */
#define COMEDI_MAJORVERSION 0

/* Comedi micro version */
#define COMEDI_MICROVERSION 76

/* Comedi minor version */
#define COMEDI_MINORVERSION 7

/* Define if 8255 support is enabled */
#define CONFIG_COMEDI_8255 true

/* Define if debugging is enabled */
#define CONFIG_COMEDI_DEBUG true

/* Define if kernel is RTAI patched */
/* #undef CONFIG_COMEDI_FUSION */

/* Define if Linux kernel source has pcmcia/cs.h (removed in 2.6.37) */
#define CONFIG_COMEDI_HAVE_CS_H true

/* Define if Linux kernel source has io_req_t in pcmcia/cs.h (removed in
   2.6.36) */
#define CONFIG_COMEDI_HAVE_CS_IO_REQ_T true

/* Define if Linux kernel source has irq_req_t in pcmcia/cs.h (removed in
   2.6.35) */
#define CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T true

/* Define if Linux kernel source has memreq_t in pcmcia/cs.h (removed in
   2.6.36) */
#define CONFIG_COMEDI_HAVE_CS_MEMREQ_T true

/* Define if Linux kernel source has pcmcia/cs_types.h (removed in 2.6.36) */
#define CONFIG_COMEDI_HAVE_CS_TYPES_H true

/* Define if Linux kernel source has dev_node_t in pcmcia/ds.h (removed in
   2.6.35) */
#define CONFIG_COMEDI_HAVE_DS_DEV_NODE_T true

/* Define if Linux kernel has linux/semaphore.h header */
#define CONFIG_COMEDI_HAVE_LINUX_SEMAPHORE_H true

/* Define if Linux kernel has mutex.h header */
#define CONFIG_COMEDI_HAVE_MUTEX_H true

/* Define if Linux kernel source has name member in struct pcmcia_driver */
/* #undef CONFIG_COMEDI_HAVE_PCMCIA_DRIVER_NAME */

/* Define if Linux kernel source has pcmcia_loop_tuple function */
#define CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE true

/* Define if PCI support is enabled */
#define CONFIG_COMEDI_PCI true

/* Define if using PCMCIA support */
/* #undef CONFIG_COMEDI_PCMCIA */

/* Define to enable Comedi's real-time support */
/* #undef CONFIG_COMEDI_RT */

/* Define if kernel is RTAI patched */
/* #undef CONFIG_COMEDI_RTAI */

/* Define if kernel is RTLinux patched */
/* #undef CONFIG_COMEDI_RTL */

/* Define if using USB support */
#define CONFIG_COMEDI_USB true

/* Define to 1 if your C compiler doesn't accept -c and -o together. */
/* #undef NO_MINUS_C_MINUS_O */

/* Name of package */
#define PACKAGE "comedi"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME "comedi"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "comedi 0.7.76"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "comedi"

/* Define to the version of this package. */
#define PACKAGE_VERSION "0.7.76"

/* Version number of package */
#define VERSION "0.7.76"
