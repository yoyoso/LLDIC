
#ifndef _COMEDI_FOPS_H
#define _COMEDI_FOPS_H

extern struct class *comedi_class;
extern const struct file_operations comedi_fops;
extern int comedi_autoconfig;

#endif //_COMEDI_FOPS_H
