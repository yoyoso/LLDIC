#define CONFIG_APCI_3120 1

#define ADDIDATA_DRIVER_NAME "addi_apci_3120"

#include "addi-data/addi_common.c"
