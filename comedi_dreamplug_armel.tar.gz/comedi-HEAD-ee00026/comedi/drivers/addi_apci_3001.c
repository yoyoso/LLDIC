#define CONFIG_APCI_3001 1

#define ADDIDATA_DRIVER_NAME "addi_apci_3001"

#include "addi-data/addi_common.c"
