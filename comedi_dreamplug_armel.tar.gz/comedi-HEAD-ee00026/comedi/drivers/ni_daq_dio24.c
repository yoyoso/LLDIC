/*
    comedi/drivers/ni_daq_dio24.c
    Driver for National Instruments PCMCIA DAQ-Card DIO-24
    Copyright (C) 2002 Daniel Vecino Castel <dvecino@able.es>

    PCMCIA stuff at end of file is adapted from dummy_cs.c 1.31 2001/08/24 12:13:13
    from the pcmcia package.
    The initial developer of the pcmcia dummy_cs.c code is David A. Hinds
    <dahinds@users.sourceforge.net>.  Portions created by David A. Hinds
    are Copyright (C) 1999 David A. Hinds.  All Rights Reserved.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

************************************************************************
*/
/*
Driver: ni_daq_dio24
Description: National Instruments PCMCIA DAQ-Card DIO-24
Author: Daniel Vecino Castel <dvecino@able.es>
Devices: [National Instruments] PCMCIA DAQ-Card DIO-24 (ni_daq_dio24)
Status: ?
Updated: Thu, 07 Nov 2002 21:53:06 -0800

This is just a wrapper around the 8255.o driver to properly handle
the PCMCIA interface.
*/

//#define LABPC_DEBUG   // enable debugging messages
#undef LABPC_DEBUG

#include <linux/comedidev.h>

#include <linux/ioport.h>
#include <linux/version.h>

#include "8255.h"

#ifdef CONFIG_COMEDI_HAVE_CS_TYPES_H
#include <pcmcia/cs_types.h>
#endif
#ifdef CONFIG_COMEDI_HAVE_CS_H
#include <pcmcia/cs.h>
#endif
#include <pcmcia/cistpl.h>
#include <pcmcia/cisreg.h>
#include <pcmcia/ds.h>

static struct pcmcia_device *pcmcia_cur_dev = NULL;

#define DIO24_SIZE 4		// size of io region used by board

static int dio24_attach(comedi_device * dev, comedi_devconfig * it);
static int dio24_detach(comedi_device * dev);

enum dio24_bustype { pcmcia_bustype };

typedef struct dio24_board_struct {
	const char *name;
	int device_id;		// device id for pcmcia board
	enum dio24_bustype bustype;	// PCMCIA
	int have_dio;		// have 8255 chip
	// function pointers so we can use inb/outb or readb/writeb as appropriate
	unsigned int (*read_byte) (unsigned int address);
	void (*write_byte) (unsigned int byte, unsigned int address);
} dio24_board;

static const dio24_board dio24_boards[] = {
	{
	      name:	"daqcard-dio24",
	      device_id:0x475c,// 0x10b is manufacturer id, 0x475c is device id
	      bustype:	pcmcia_bustype,
	      have_dio:1,
		},
	{
	      name:	"ni_daq_dio24",
	      device_id:0x475c,// 0x10b is manufacturer id, 0x475c is device id
	      bustype:	pcmcia_bustype,
	      have_dio:1,
		},
};

/*
 * Useful for shorthand access to the particular board structure
 */
#define thisboard ((const dio24_board *)dev->board_ptr)

typedef struct {
	int data;		/* number of data points left to be taken */
} dio24_private;

#define devpriv ((dio24_private *)dev->private)

static comedi_driver driver_dio24 = {
      driver_name:"ni_daq_dio24",
      module:THIS_MODULE,
      attach:dio24_attach,
      detach:dio24_detach,
      num_names:sizeof(dio24_boards) / sizeof(dio24_board),
      board_name:&dio24_boards[0].name,
      offset:sizeof(dio24_board),
};

static int dio24_attach(comedi_device * dev, comedi_devconfig * it)
{
	comedi_subdevice *s;
	unsigned long iobase = 0;
#ifdef incomplete
	unsigned int irq = 0;
#endif
	struct pcmcia_device *link;

	/* allocate and initialize dev->private */
	if (alloc_private(dev, sizeof(dio24_private)) < 0)
		return -ENOMEM;

	// get base address, irq etc. based on bustype
	switch (thisboard->bustype) {
	case pcmcia_bustype:
		link = pcmcia_cur_dev;	/* XXX hack */
		if (!link)
			return -EIO;
#ifdef CONFIG_COMEDI_HAVE_CS_IO_REQ_T
		iobase = link->io.BasePort1;
#else
		iobase = link->resource[0]->start;
#endif
#ifdef incomplete
#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
		irq = link->irq.AssignedIRQ;
#else
		irq = link->irq;
#endif
#endif
		break;
	default:
		printk("bug! couldn't determine board type\n");
		return -EINVAL;
		break;
	}
	printk("comedi%d: ni_daq_dio24: %s, io 0x%lx", dev->minor,
		thisboard->name, iobase);
#ifdef incomplete
	if (irq) {
		printk(", irq %u", irq);
	}
#endif

	printk("\n");

	if (iobase == 0) {
		printk("io base address is zero!\n");
		return -EINVAL;
	}

	dev->iobase = iobase;

#ifdef incomplete
	/* grab our IRQ */
	dev->irq = irq;
#endif

	dev->board_name = thisboard->name;

	if (alloc_subdevices(dev, 1) < 0)
		return -ENOMEM;

	/* 8255 dio */
	s = dev->subdevices + 0;
	subdev_8255_init(dev, s, NULL, dev->iobase);

	return 0;
};

static int dio24_detach(comedi_device * dev)
{
	printk("comedi%d: ni_daq_dio24: remove\n", dev->minor);

	if (dev->subdevices)
		subdev_8255_cleanup(dev, dev->subdevices + 0);

	if (thisboard->bustype != pcmcia_bustype && dev->iobase)
		release_region(dev->iobase, DIO24_SIZE);
	if (dev->irq)
		comedi_free_irq(dev->irq, dev);

	return 0;
};

/*
   All the PCMCIA modules use PCMCIA_DEBUG to control debugging.  If
   you do not define PCMCIA_DEBUG at all, all the debug code will be
   left out.  If you compile with PCMCIA_DEBUG=0, the debug code will
   be present but disabled -- but it can then be enabled for specific
   modules at load time with a 'pc_debug=#' option to insmod.
*/
#ifdef PCMCIA_DEBUG
static int pc_debug = PCMCIA_DEBUG;
module_param(pc_debug, int, 0644);
#define DEBUG(n, args...) if (pc_debug>(n)) printk(KERN_DEBUG args)
static char *version = "ni_daq_dio24.c, based on dummy_cs.c";
#else
#define DEBUG(n, args...)
#endif

/*====================================================================*/

static void dio24_config(struct pcmcia_device *link);
static void dio24_release(struct pcmcia_device *link);
static int dio24_cs_suspend(struct pcmcia_device *p_dev);
static int dio24_cs_resume(struct pcmcia_device *p_dev);

/*
   The attach() and detach() entry points are used to create and destroy
   "instances" of the driver, where each instance represents everything
   needed to manage one actual PCMCIA card.
*/

static int dio24_cs_attach(struct pcmcia_device *);
static void dio24_cs_detach(struct pcmcia_device *);

/*
   You'll also need to prototype all the functions that will actually
   be used to talk to your device.  See 'memory_cs' for a good example
   of a fully self-sufficient driver; the other drivers rely more or
   less on other parts of the kernel.
*/

/*
   The devname variable is the "key" that is used to match up this
   device driver with appropriate cards, through the card configuration
   database.
*/

#ifdef CONFIG_COMEDI_HAVE_CS_TYPES_H
static const dev_info_t devname = "ni_daq_dio24";
#else
static const char devname[] = "ni_daq_dio24";
#endif

typedef struct local_info_t {
	struct pcmcia_device *link;
#ifdef CONFIG_COMEDI_HAVE_DS_DEV_NODE_T
	dev_node_t node;
#endif
	int stop;
	struct bus_operations *bus;
} local_info_t;

/*======================================================================

    dio24_cs_attach() creates an "instance" of the driver, allocating
    local data structures for one device.  The device is registered
    with Card Services.

    The dev_link structure is initialized, but we don't actually
    configure the card at this point -- we wait until we receive a
    card insertion event.

======================================================================*/

static int dio24_cs_attach(struct pcmcia_device *link)
{
	local_info_t *local;

	printk(KERN_INFO "ni_daq_dio24: HOLA SOY YO - CS-attach!\n");

	DEBUG(0, "dio24_cs_attach()\n");

	/* Allocate space for private device-specific data */
	local = kzalloc(sizeof(local_info_t), GFP_KERNEL);
	if (!local)
		return -ENOMEM;
	local->link = link;
	link->priv = local;

#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
	/* Interrupt setup */
	link->irq.Attributes = IRQ_TYPE_DYNAMIC_SHARING;
#ifndef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
	link->irq.IRQInfo1 = IRQ_LEVEL_ID;
#endif
	link->irq.Handler = NULL;
#endif

#ifdef CONFIG_COMEDI_HAVE_CS_H
	/*
	   General socket configuration defaults can go here.  In this
	   client, we assume very little, and rely on the CIS for almost
	   everything.  In most clients, many details (i.e., number, sizes,
	   and attributes of IO windows) are fixed by the nature of the
	   device, and can be hard-wired here.
	 */
	link->conf.Attributes = 0;
	link->conf.IntType = INT_MEMORY_AND_IO;
#endif

	pcmcia_cur_dev = link;

	dio24_config(link);

	return 0;
}				/* dio24_cs_attach */

/*======================================================================

    This deletes a driver "instance".  The device is de-registered
    with Card Services.  If it has been released, all local data
    structures are freed.  Otherwise, the structures will be freed
    when the device is released.

======================================================================*/

static void dio24_cs_detach(struct pcmcia_device *link)
{

	printk(KERN_INFO "ni_daq_dio24: HOLA SOY YO - cs-detach!\n");

	DEBUG(0, "dio24_cs_detach(0x%p)\n", link);

#ifdef CONFIG_COMEDI_HAVE_DS_DEV_NODE_T
	if (link->dev_node)
#endif
	{
		((local_info_t *) link->priv)->stop = 1;
		dio24_release(link);
	}

	/* This points to the parent local_info_t struct */
	if (link->priv)
		kfree(link->priv);

}				/* dio24_cs_detach */

/*======================================================================

    dio24_config() is scheduled to run after a CARD_INSERTION event
    is received, to configure the PCMCIA socket, and to make the
    device available to the system.

======================================================================*/

#ifdef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
#ifdef CONFIG_COMEDI_HAVE_CS_H
static int dio24_pcmcia_config_loop(struct pcmcia_device *p_dev,
				cistpl_cftable_entry_t *cfg,
				cistpl_cftable_entry_t *dflt,
				unsigned int vcc,
				void *priv_data)
{
	win_req_t *req = priv_data;
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
	memreq_t map;
#endif

	if (cfg->index == 0)
		return -ENODEV;

	/* Does this card need audio output? */
	if (cfg->flags & CISTPL_CFTABLE_AUDIO) {
		p_dev->conf.Attributes |= CONF_ENABLE_SPKR;
		p_dev->conf.Status = CCSR_AUDIO_ENA;
	}

	/* Do we need to allocate an interrupt? */
#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
	if (cfg->irq.IRQInfo1 || dflt->irq.IRQInfo1)
#endif
	{
		p_dev->conf.Attributes |= CONF_ENABLE_IRQ;
	}

	/* IO window settings */
#ifdef CONFIG_COMEDI_HAVE_CS_IO_REQ_T
	p_dev->io.NumPorts1 = p_dev->io.NumPorts2 = 0;
	if ((cfg->io.nwin > 0) || (dflt->io.nwin > 0)) {
		cistpl_io_t *io = (cfg->io.nwin) ? &cfg->io : &dflt->io;
		p_dev->io.Attributes1 = IO_DATA_PATH_WIDTH_AUTO;
		if (!(io->flags & CISTPL_IO_8BIT))
			p_dev->io.Attributes1 = IO_DATA_PATH_WIDTH_16;
		if (!(io->flags & CISTPL_IO_16BIT))
			p_dev->io.Attributes1 = IO_DATA_PATH_WIDTH_8;
		p_dev->io.IOAddrLines = io->flags & CISTPL_IO_LINES_MASK;
		p_dev->io.BasePort1 = io->win[0].base;
		p_dev->io.NumPorts1 = io->win[0].len;
		if (io->nwin > 1) {
			p_dev->io.Attributes2 = p_dev->io.Attributes1;
			p_dev->io.BasePort2 = io->win[1].base;
			p_dev->io.NumPorts2 = io->win[1].len;
		}
		/* This reserves IO space but doesn't actually enable it */
		if (pcmcia_request_io(p_dev, &p_dev->io) != 0)
			return -ENODEV;
	}
#else
	p_dev->resource[0]->end = p_dev->resource[1]->end = 0;
	if ((cfg->io.nwin > 0) || (dflt->io.nwin > 0)) {
		cistpl_io_t *io = (cfg->io.nwin) ? &cfg->io : &dflt->io;
		p_dev->io_lines = io->flags & CISTPL_IO_LINES_MASK;
		p_dev->resource[0]->flags &= ~IO_DATA_PATH_WIDTH;
		p_dev->resource[0]->flags |=
			pcmcia_io_cfg_data_width(io->flags);
		p_dev->resource[0]->start = io->win[0].base;
		p_dev->resource[0]->end = io->win[0].len;
		if (io->nwin > 1) {
			p_dev->resource[1]->flags = p_dev->resource[0]->flags;
			p_dev->resource[1]->start = io->win[1].base;
			p_dev->resource[1]->end = io->win[1].len;
		}
		/* This reserves IO space but doesn't actually enable it */
		if (pcmcia_request_io(p_dev) != 0)
			return -ENODEV;
	}
#endif

	if ((cfg->mem.nwin > 0) || (dflt->mem.nwin > 0)) {
		cistpl_mem_t *mem =
			(cfg->mem.nwin) ? &cfg->mem : &dflt->mem;
		req->Attributes = WIN_DATA_WIDTH_16 | WIN_MEMORY_TYPE_CM;
		req->Attributes |= WIN_ENABLE;
		req->Base = mem->win[0].host_addr;
		req->Size = mem->win[0].len;
		if (req->Size < 0x1000)
			req->Size = 0x1000;
		req->AccessSpeed = 0;
		if (pcmcia_request_window(p_dev, req, &p_dev->win))
			return -ENODEV;
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
		map.Page = 0;
		map.CardOffset = mem->win[0].card_addr;
#endif
		if (pcmcia_map_mem_page(p_dev, p_dev->win,
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
					&map
#else
					mem->win[0].card_addr
#endif
					))
			return -ENODEV;
	}
	/* If we got this far, we're cool! */
	return 0;
}
#else	/* CONFIG_COMEDI_HAVE_CS_H */
static int dio24_pcmcia_config_loop(struct pcmcia_device *p_dev,
				void *priv_data)
{
	if (p_dev->config_index == 0)
		return -EINVAL;

	return pcmcia_request_io(p_dev);
}
#endif	/* CONFIG_COMEDI_HAVE_CS_H */
#endif	/* CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE */

static void dio24_config(struct pcmcia_device *link)
{
#ifdef CONFIG_COMEDI_HAVE_DS_DEV_NODE_T
	local_info_t *dev = link->priv;
#endif
	int last_ret;
#ifdef CONFIG_COMEDI_HAVE_CS_H
	win_req_t req;
#endif
#ifndef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
	tuple_t tuple;
	cisparse_t parse;
	int last_fn;
	u_char buf[64];
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
	memreq_t map;
#endif
	cistpl_cftable_entry_t dflt = { 0 };
#endif

	printk(KERN_INFO "ni_daq_dio24: HOLA SOY YO! - config\n");

	DEBUG(0, "dio24_config(0x%p)\n", link);

#ifndef CONFIG_COMEDI_HAVE_CS_H
	link->config_flags |= CONF_ENABLE_IRQ | CONF_AUTO_AUDIO |
		CONF_AUTO_SET_IO;
#endif

#ifdef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
	last_ret = pcmcia_loop_config(link, dio24_pcmcia_config_loop,
#ifdef CONFIG_COMEDI_HAVE_CS_H
			&req
#else
			NULL
#endif
			);
	if (last_ret) {
		dev_warn(&link->dev, "no configuration found\n");
		goto cs_failed;
	}
#else
	/*
	   This reads the card's CONFIG tuple to find its configuration
	   registers.
	 */
	tuple.DesiredTuple = CISTPL_CONFIG;
	tuple.Attributes = 0;
	tuple.TupleData = buf;
	tuple.TupleDataMax = sizeof(buf);
	tuple.TupleOffset = 0;
	last_fn = GetFirstTuple;
	if ((last_ret = pcmcia_get_first_tuple(link, &tuple)) != 0) {
		goto cs_failed;
	}
	last_fn = GetTupleData;
	if ((last_ret = pcmcia_get_tuple_data(link, &tuple)) != 0) {
		goto cs_failed;
	}
	last_fn = ParseTuple;
	if ((last_ret = pcmcia_parse_tuple(&tuple, &parse)) != 0) {
		goto cs_failed;
	}
	link->conf.ConfigBase = parse.config.base;
	link->conf.Present = parse.config.rmask[0];

	/*
	   In this loop, we scan the CIS for configuration table entries,
	   each of which describes a valid card configuration, including
	   voltage, IO window, memory window, and interrupt settings.

	   We make no assumptions about the card to be configured: we use
	   just the information available in the CIS.  In an ideal world,
	   this would work for any PCMCIA card, but it requires a complete
	   and accurate CIS.  In practice, a driver usually "knows" most of
	   these things without consulting the CIS, and most client drivers
	   will only use the CIS to fill in implementation-defined details.
	 */
	tuple.DesiredTuple = CISTPL_CFTABLE_ENTRY;
	last_fn = GetFirstTuple;
	if ((last_ret = pcmcia_get_first_tuple(link, &tuple)) != 0) {
		goto cs_failed;
	}
	while (1) {
		cistpl_cftable_entry_t *cfg = &(parse.cftable_entry);
		if (pcmcia_get_tuple_data(link, &tuple) != 0)
			goto next_entry;
		if (pcmcia_parse_tuple(&tuple, &parse) != 0)
			goto next_entry;

		if (cfg->flags & CISTPL_CFTABLE_DEFAULT)
			dflt = *cfg;
		if (cfg->index == 0)
			goto next_entry;
		link->conf.ConfigIndex = cfg->index;

		/* Does this card need audio output? */
		if (cfg->flags & CISTPL_CFTABLE_AUDIO) {
			link->conf.Attributes |= CONF_ENABLE_SPKR;
			link->conf.Status = CCSR_AUDIO_ENA;
		}

		/* Do we need to allocate an interrupt? */
#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
		if (cfg->irq.IRQInfo1 || dflt.irq.IRQInfo1)
#endif
		{
			link->conf.Attributes |= CONF_ENABLE_IRQ;
		}

		/* IO window settings */
#ifdef CONFIG_COMEDI_HAVE_CS_IO_REQ_T
		link->io.NumPorts1 = link->io.NumPorts2 = 0;
		if ((cfg->io.nwin > 0) || (dflt.io.nwin > 0)) {
			cistpl_io_t *io = (cfg->io.nwin) ? &cfg->io : &dflt.io;
			link->io.Attributes1 = IO_DATA_PATH_WIDTH_AUTO;
			if (!(io->flags & CISTPL_IO_8BIT))
				link->io.Attributes1 = IO_DATA_PATH_WIDTH_16;
			if (!(io->flags & CISTPL_IO_16BIT))
				link->io.Attributes1 = IO_DATA_PATH_WIDTH_8;
			link->io.IOAddrLines = io->flags & CISTPL_IO_LINES_MASK;
			link->io.BasePort1 = io->win[0].base;
			link->io.NumPorts1 = io->win[0].len;
			if (io->nwin > 1) {
				link->io.Attributes2 = link->io.Attributes1;
				link->io.BasePort2 = io->win[1].base;
				link->io.NumPorts2 = io->win[1].len;
			}
			/* This reserves IO space but doesn't actually enable it */
			if (pcmcia_request_io(link, &link->io) != 0)
				goto next_entry;
		}
#else
		link->resource[0]->end = link->resource[1]->end = 0;
		if ((cfg->io.nwin > 0) || (dflt.io.nwin > 0)) {
			cistpl_io_t *io = (cfg->io.nwin) ? &cfg->io : &dflt.io;
			link->io_lines = io->flags & CISTPL_IO_LINES_MASK;
			link->resource[0]->flags &= ~IO_DATA_PATH_WIDTH;
			link->resource[0]->flags |=
				pcmcia_io_cfg_data_width(io->flags);
			link->resource[0]->start = io->win[0].base;
			link->resource[0]->end = io->win[0].len;
			if (io->nwin > 1) {
				link->resource[1]->flags = p_dev->resource[0]->flags;
				link->resource[1]->start = io->win[1].base;
				link->resource[1]->end = io->win[1].len;
			}
			/* This reserves IO space but doesn't actually enable it */
			if (pcmcia_request_io(link) != 0)
				goto next_entry;
		}
#endif

		if ((cfg->mem.nwin > 0) || (dflt.mem.nwin > 0)) {
			cistpl_mem_t *mem =
				(cfg->mem.nwin) ? &cfg->mem : &dflt.mem;
			req.Attributes = WIN_DATA_WIDTH_16 | WIN_MEMORY_TYPE_CM;
			req.Attributes |= WIN_ENABLE;
			req.Base = mem->win[0].host_addr;
			req.Size = mem->win[0].len;
			if (req.Size < 0x1000)
				req.Size = 0x1000;
			req.AccessSpeed = 0;
			if (pcmcia_request_window(&link, &req, &link->win))
				goto next_entry;
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
			map.Page = 0;
			map.CardOffset = mem->win[0].card_addr;
#endif
			if (pcmcia_map_mem_page(link->win,
#ifdef CONFIG_COMEDI_HAVE_CS_MEMREQ_T
						&map
#else
						mem->win[0].card_addr
#endif
						))
				goto next_entry;
		}
		/* If we got this far, we're cool! */
		break;

	      next_entry:
		last_fn = GetNextTuple;
		if ((last_ret = pcmcia_get_next_tuple(link, &tuple)) != 0) {
			goto cs_failed;
		}
	}
#endif

#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
	/*
	   Allocate an interrupt line.  Note that this does not assign a
	   handler to the interrupt, unless the 'Handler' member of the
	   irq structure is initialized.
	 */
	if (link->conf.Attributes & CONF_ENABLE_IRQ)
#ifndef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
		last_fn = RequestIRQ;
#endif
		if ((last_ret = pcmcia_request_irq(link, &link->irq)) != 0) {
			goto cs_failed;
		}
#else
	/* Check an interrupt line has been allocated. */
	if (!link->irq)
		goto cs_failed;
#endif

	/*
	   This actually configures the PCMCIA socket -- setting up
	   the I/O windows and the interrupt mapping, and putting the
	   card and host interface into "Memory and IO" mode.
	 */
#ifndef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
	last_fn = RequestConfiguration;
#endif
#ifdef CONFIG_COMEDI_HAVE_CS_H
	last_ret = pcmcia_request_configuration(link, &link->conf);
#else
	last_ret = pcmcia_enable_device(link);
#endif
	if (last_ret)
		goto cs_failed;

#ifdef CONFIG_COMEDI_HAVE_DS_DEV_NODE_T
	/*
	   At this point, the dev_node_t structure(s) need to be
	   initialized and arranged in a linked list at link->dev.
	 */
	sprintf(dev->node.dev_name, "ni_daq_dio24");
	dev->node.major = dev->node.minor = 0;
	link->dev_node = &dev->node;
#endif

#ifdef CONFIG_COMEDI_HAVE_CS_H
	/* Finally, report what we've done */
#ifdef CONFIG_COMEDI_HAVE_DS_DEV_NODE_T
	printk(KERN_INFO "%s: index 0x%02x",
		dev->node.dev_name, link->conf.ConfigIndex);
#else
	dev_info(&link->dev, "index 0x%02x", link->conf.ConfigIndex);
#endif
	if (link->conf.Attributes & CONF_ENABLE_IRQ)
		printk(", irq %u",
#ifdef CONFIG_COMEDI_HAVE_CS_IRQ_REQ_T
			link->irq.AssignedIRQ
#else
			link->irq
#endif
			);
#ifdef CONFIG_COMEDI_HAVE_CS_IO_REQ_T
	if (link->io.NumPorts1)
		printk(", io 0x%04x-0x%04x", link->io.BasePort1,
			link->io.BasePort1 + link->io.NumPorts1 - 1);
	if (link->io.NumPorts2)
		printk(" & 0x%04x-0x%04x", link->io.BasePort2,
			link->io.BasePort2 + link->io.NumPorts2 - 1);
#else
	if (link->resource[0])
		printk(", io %pR", link->resource[0]);
	if (link->resource[1])
		printk(" & %pR", link->resource[1]);
#endif
	if (link->win)
		printk(", mem 0x%06lx-0x%06lx", req.Base,
			req.Base + req.Size - 1);
	printk("\n");
#endif	/* CONFIG_COMEDI_HAVE_CS_H */

	return;

      cs_failed:
#ifndef CONFIG_COMEDI_HAVE_PCMCIA_LOOP_TUPLE
	cs_error(link, last_fn, last_ret);
#endif
	printk(KERN_INFO "Fallo");
	dio24_release(link);

}				/* dio24_config */

static void dio24_release(struct pcmcia_device *link)
{
	DEBUG(0, "dio24_release(0x%p)\n", link);

	pcmcia_disable_device(link);
}				/* dio24_release */

/*======================================================================

    The card status event handler.  Mostly, this schedules other
    stuff to run after an event is received.

    When a CARD_REMOVAL event is received, we immediately set a
    private flag to block future accesses to this device.  All the
    functions that actually access the device should check this flag
    to make sure the card is still present.

======================================================================*/

static int dio24_cs_suspend(struct pcmcia_device *link)
{
	local_info_t *local = link->priv;

	/* Mark the device as stopped, to block IO until later */
	local->stop = 1;
	return 0;
}				/* dio24_cs_suspend */

static int dio24_cs_resume(struct pcmcia_device *link)
{
	local_info_t *local = link->priv;

	local->stop = 0;
	return 0;
}				/* dio24_cs_resume */

/*====================================================================*/

static struct pcmcia_device_id dio24_cs_ids[] = {
	/* N.B. These IDs should match those in dio24_boards */
	PCMCIA_DEVICE_MANF_CARD(0x010b, 0x475c),	/* daqcard-dio24 */
	PCMCIA_DEVICE_NULL
};

MODULE_DEVICE_TABLE(pcmcia, dio24_cs_ids);

struct pcmcia_driver dio24_cs_driver = {
	.probe = dio24_cs_attach,
	.remove = dio24_cs_detach,
	.suspend = dio24_cs_suspend,
	.resume = dio24_cs_resume,
	.id_table = dio24_cs_ids,
	.owner = THIS_MODULE,
#ifdef CONFIG_COMEDI_HAVE_PCMCIA_DRIVER_NAME
	.name = devname,
#else
	.drv = {
			.name = devname,
		},
#endif
};

static int __init init_dio24_cs(void)
{
	printk("ni_daq_dio24: HOLA SOY YO!\n");
	DEBUG(0, "%s\n", version);
	pcmcia_register_driver(&dio24_cs_driver);
	return 0;
}

static void __exit exit_dio24_cs(void)
{
	DEBUG(0, "ni_dio24: unloading\n");
	pcmcia_unregister_driver(&dio24_cs_driver);
}

int __init init_module(void)
{
	int ret;

	ret = init_dio24_cs();
	if (ret < 0)
		return ret;

	return comedi_driver_register(&driver_dio24);
}

void __exit cleanup_module(void)
{
	exit_dio24_cs();
	comedi_driver_unregister(&driver_dio24);
}
