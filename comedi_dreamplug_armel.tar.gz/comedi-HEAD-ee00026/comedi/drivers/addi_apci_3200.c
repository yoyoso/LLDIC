#define CONFIG_APCI_3200 1

#define ADDIDATA_DRIVER_NAME "addi_apci_3200"

#include "addi-data/addi_common.c"
