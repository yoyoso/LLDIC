/* THIS IS A GENERATED FILE. DO NOT EDIT! */

#ifndef INC_epicsInstallDir_H
#define INC_epicsInstallDir_H

#define EPICS_BASE "/usr/local/epics/base-3.14.12.1"

#endif /* INC_epicsInstallDir_H */
