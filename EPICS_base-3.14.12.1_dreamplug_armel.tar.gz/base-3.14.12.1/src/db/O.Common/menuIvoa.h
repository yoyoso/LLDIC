#ifndef INCmenuIvoaH
#define INCmenuIvoaH
typedef enum {
	menuIvoaContinue_normally,
	menuIvoaDon_t_drive_outputs,
	menuIvoaSet_output_to_IVOV
}menuIvoa;
#endif /*INCmenuIvoaH*/
