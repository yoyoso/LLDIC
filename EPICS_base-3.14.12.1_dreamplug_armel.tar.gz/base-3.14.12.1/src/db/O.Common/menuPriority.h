#ifndef INCmenuPriorityH
#define INCmenuPriorityH
typedef enum {
	menuPriorityLOW,
	menuPriorityMEDIUM,
	menuPriorityHIGH
}menuPriority;
#endif /*INCmenuPriorityH*/
