#ifndef INCmenuFtypeH
#define INCmenuFtypeH
typedef enum {
	menuFtypeSTRING,
	menuFtypeCHAR,
	menuFtypeUCHAR,
	menuFtypeSHORT,
	menuFtypeUSHORT,
	menuFtypeLONG,
	menuFtypeULONG,
	menuFtypeFLOAT,
	menuFtypeDOUBLE,
	menuFtypeENUM
}menuFtype;
#endif /*INCmenuFtypeH*/
