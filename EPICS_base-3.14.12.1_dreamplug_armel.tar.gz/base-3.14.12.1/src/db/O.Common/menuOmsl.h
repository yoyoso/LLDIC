#ifndef INCmenuOmslH
#define INCmenuOmslH
typedef enum {
	menuOmslsupervisory,
	menuOmslclosed_loop
}menuOmsl;
#endif /*INCmenuOmslH*/
