#ifndef INCmenuAlarmSevrH
#define INCmenuAlarmSevrH
typedef enum {
	menuAlarmSevrNO_ALARM,
	menuAlarmSevrMINOR,
	menuAlarmSevrMAJOR,
	menuAlarmSevrINVALID
}menuAlarmSevr;
#endif /*INCmenuAlarmSevrH*/
