#ifndef INCmenuSimmH
#define INCmenuSimmH
typedef enum {
	menuSimmNO,
	menuSimmYES,
	menuSimmRAW
}menuSimm;
#endif /*INCmenuSimmH*/
