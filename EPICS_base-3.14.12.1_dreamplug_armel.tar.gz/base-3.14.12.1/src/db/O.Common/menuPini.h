#ifndef INCmenuPiniH
#define INCmenuPiniH
typedef enum {
	menuPiniNO,
	menuPiniYES,
	menuPiniRUN,
	menuPiniRUNNING,
	menuPiniPAUSE,
	menuPiniPAUSED
}menuPini;
#endif /*INCmenuPiniH*/
