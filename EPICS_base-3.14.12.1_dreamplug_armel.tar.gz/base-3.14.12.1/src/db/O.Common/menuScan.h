#ifndef INCmenuScanH
#define INCmenuScanH
typedef enum {
	menuScanPassive,
	menuScanEvent,
	menuScanI_O_Intr,
	menuScan10_second,
	menuScan5_second,
	menuScan2_second,
	menuScan1_second,
	menuScan_5_second,
	menuScan_2_second,
	menuScan_1_second
}menuScan;
#endif /*INCmenuScanH*/
