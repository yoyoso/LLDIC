#ifndef INCmenuAlarmStatH
#define INCmenuAlarmStatH
typedef enum {
	menuAlarmStatNO_ALARM,
	menuAlarmStatREAD,
	menuAlarmStatWRITE,
	menuAlarmStatHIHI,
	menuAlarmStatHIGH,
	menuAlarmStatLOLO,
	menuAlarmStatLOW,
	menuAlarmStatSTATE,
	menuAlarmStatCOS,
	menuAlarmStatCOMM,
	menuAlarmStatTIMEOUT,
	menuAlarmStatHWLIMIT,
	menuAlarmStatCALC,
	menuAlarmStatSCAN,
	menuAlarmStatLINK,
	menuAlarmStatSOFT,
	menuAlarmStatBAD_SUB,
	menuAlarmStatUDF,
	menuAlarmStatDISABLE,
	menuAlarmStatSIMM,
	menuAlarmStatREAD_ACCESS,
	menuAlarmStatWRITE_ACCESS
}menuAlarmStat;
#endif /*INCmenuAlarmStatH*/
