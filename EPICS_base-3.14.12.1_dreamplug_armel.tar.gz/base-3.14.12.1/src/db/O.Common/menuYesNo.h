#ifndef INCmenuYesNoH
#define INCmenuYesNoH
typedef enum {
	menuYesNoNO,
	menuYesNoYES
}menuYesNo;
#endif /*INCmenuYesNoH*/
