#ifndef INCmenuCompressH
#define INCmenuCompressH
typedef enum {
	menuCompressN_to_1_First_Value,
	menuCompressN_to_1_Low_Value,
	menuCompressN_to_1_High_Value,
	menuCompressN_to_1_Average
}menuCompress;
#endif /*INCmenuCompressH*/
