#ifndef INCmenuConvertH
#define INCmenuConvertH
typedef enum {
	menuConvertNO_CONVERSION,
	menuConvertSLOPE,
	menuConvertLINEAR,
	menuConverttypeKdegF,
	menuConverttypeKdegC,
	menuConverttypeJdegF,
	menuConverttypeJdegC,
	menuConverttypeEdegF,
	menuConverttypeEdegC,
	menuConverttypeTdegF,
	menuConverttypeTdegC,
	menuConverttypeRdegF,
	menuConverttypeRdegC,
	menuConverttypeSdegF,
	menuConverttypeSdegC
}menuConvert;
#endif /*INCmenuConvertH*/
